def parse_time_value(value):
    """Convert time values with suffixes to seconds
    
    Examples:
        120s -> 120 (seconds)
        5m -> 300 (seconds)
        2h -> 7200 (seconds)
        1d -> 86400 (seconds)
    
    Args:
        value: Time value with optional suffix (s, m, h, d)
        
    Returns:
        int: Time value in seconds
    """
    if isinstance(value, (int, float)):
        return int(value)  # Assume seconds if no suffix
        
    if isinstance(value, str):
        value = value.strip().lower()
        
        # Check for suffixes
        if value.endswith('s'):
            try:
                return int(float(value[:-1]))
            except ValueError:
                pass
        elif value.endswith('m'):
            try:
                return int(float(value[:-1]) * 60)
            except ValueError:
                pass
        elif value.endswith('h'):
            try:
                return int(float(value[:-1]) * 3600)
            except ValueError:
                pass
        elif value.endswith('d'):
            try:
                return int(float(value[:-1]) * 86400)
            except ValueError:
                pass
        else:
            # Try to convert directly to int if no suffix
            try:
                return int(float(value))
            except ValueError:
                pass
    
    # Default fallback
    return 60  # Default to 60 seconds 